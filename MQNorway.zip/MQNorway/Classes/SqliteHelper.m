//
//  SqliteHelper.m
//  MQNorway
//
//  Created by knut dullum on 20/03/2011.
//  Copyright 2011 lemmus. All rights reserved.
//

#import "SqliteHelper.h"


@implementation SqliteHelper

+(Sqlite*) Instance 
{
	static Sqlite *Instance;
	
	@synchronized(self) {
		if(!Instance)
		{
			Instance = [[Sqlite alloc] init];
            
            
			
			NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
			NSString *documentsDirectory = [paths objectAtIndex:0];
			NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"SQLiteTest.db"];
			if (![Instance open:writableDBPath])
				return;
			
			//NSArray *existsResult = [Instance executeQuery:@"SELECT name FROM sqlite_master WHERE type='table' AND name='location';"];
			NSArray *existsResult = [Instance executeQuery:@"SELECT name FROM sqlite_master WHERE type='table' AND name='bogusThree';"];
			if([existsResult count] == 0)
			{
                //resetting the whole local database
				
				[Instance executeNonQuery:@"PRAGMA foreign_keys =off;"];
				[Instance executeNonQuery:@"DROP TABLE question"];
				[Instance executeNonQuery:@"CREATE TABLE question ("
				 "questionID VARCHAR(25) PRIMARY KEY,locationRef VARCHAR(25),difficulty VARCHAR(25),"
				 "picture VARCHAR(25), hint VARCHAR(25),hintOrgLan VARCHAR(25),  english TEXT(25), norwegian TEXT(25), spanish TEXT(25),french TEXT(25),german TEXT(25));"];
				  //"FOREIGN KEY(locationRef) REFERENCES location(locationID));"];
				
				//primary key failes
				[Instance executeNonQuery:@"DROP TABLE answer"];
				[Instance executeNonQuery:@"CREATE TABLE answer ("
				 "answerID VARCHAR(25) PRIMARY KEY, picture VARCHAR(25), middleFixEnglish TEXT, middleFixNorwegian TEXT, middleFixSpanish TEXT,"
				 "middleFixFrench TEXT,middleFixGerman TEXT);"];
				
				[Instance executeNonQuery:@"DROP TABLE additionalInfo"];
				[Instance executeNonQuery:@"CREATE TABLE additionalInfo ("
				 "infoID VARCHAR(25) PRIMARY KEY, infoEnglish TEXT, infoNorwegian TEXT, infoSpanish TEXT,"
				 "infoFrench TEXT,infoGerman TEXT);"];
				
				[Instance executeNonQuery:@"DROP TABLE coordinates"];
				[Instance executeNonQuery:@"CREATE TABLE coordinates ("
				 "coordinateID VARCHAR(25) PRIMARY KEY, withincoordinateID VARCHAR(25), kmtolerance NUMERIC NOT NULL, coordinates TEXT,"
				 "lineRefs TEXT,population NUMERIC, infoRef VARCHAR(25));"];
				 //"FOREIGN KEY(infoRef) REFERENCES additionalInfo(infoID),"
				 //"FOREIGN KEY(withincoordinateID) REFERENCES coordinates(coordinateID));"];
				
				//no real coupling between coordinates and line. Coordinate has a commaseparated list of line ids (lineRefs)
				[Instance executeNonQuery:@"DROP TABLE line"];
				[Instance executeNonQuery:@"CREATE TABLE line ("
				 "lineID TEXT PRIMARY KEY, coordinates TEXT);"];
				
				[Instance executeNonQuery:@"DROP TABLE location"];
				[Instance executeNonQuery:@"CREATE TABLE location ("
				 "locationID VARCHAR(25) PRIMARY KEY, locationNames TEXT,"
				 "locationNameEng TEXT, locationNameNor TEXT, locationNameSpn TEXT, locationNameFra TEXT, locationNameGer TEXT,"
				 "locationtype VARCHAR(25)," 
				 "selectionChance NUMERIC NOT NULL, sumAnswers NUMERIC NOT NULL, avgDistance REAL," 
				 "coordianteRef VARCHAR(25),answerRef VARCHAR(25),"
				 "excludedCoordinatesRefs TEXT,"
				 "includedCoordinatesRefs TEXT);"];
				 //"FOREIGN KEY(coordianteRef) REFERENCES coordinates(coordianteID),"
				 //"FOREIGN KEY(answerRef) REFERENCES answer(answerID));"];
				
				
				[Instance executeNonQuery:@"DROP TABLE savestate"];
				[Instance executeNonQuery:@"CREATE TABLE savestate ("
				 "savestateID VARCHAR(25) PRIMARY KEY,shouldRestoreFlag VARCHAR(25),"
				 "playersRefs TEXT,gameType TEXT,playerRefTurn TEXT,language TEXT, currentView TEXT, questionID TEXT,"
				 "numberOfQuestions NUMERIC, gameState TEXT,gameQuestionsPassed NUMERIC);"];
				
				
				[Instance executeNonQuery:@"DROP TABLE player"];
				[Instance executeNonQuery:@"CREATE TABLE player ("
				 "playerID VARCHAR(25) ,name TEXT PRIMARY KEY,gamemarkerPoint TEXT,secondsUsed NUMERIC,"
				 "questionsPassed NUMERIC,distanceLeft NUMERIC,score NUMERIC,"
				 "totalDistance NUMERIC, barWidth NUMERIC, isOut BOOL,symbol TEXT);"];
				
				[Instance executeNonQuery:@"DROP TABLE firstinstructions"];
				[Instance executeNonQuery:@"CREATE TABLE firstinstructions ("
				 "playername TEXT, datestamp TEXT);"];
				
				[Instance executeNonQuery:@"DROP TABLE globalID"];
				[Instance executeNonQuery:@"CREATE TABLE globalID ("
				 "playerID TEXT, nationality TEXT, playerGuid TEXT);"];
				
				[Instance executeNonQuery:@"DROP TABLE bogusThree"];
				[Instance executeNonQuery:@"CREATE TABLE bogusThree ("
				 "bogusname TEXT);"];
				
			
				[Instance executeNonQuery:@"DELETE FROM savestate;"];
				[Instance executeNonQuery:@"DELETE FROM player;"];
				[Instance executeNonQuery:@"DELETE FROM line;"];
				[Instance executeNonQuery:@"DELETE FROM location;"];
				[Instance executeNonQuery:@"DELETE FROM question;"];
				[Instance executeNonQuery:@"DELETE FROM answer;"];
				[Instance executeNonQuery:@"DELETE FROM coordinates;"];
				[Instance executeNonQuery:@"DELETE FROM additionalInfo;"];
			}
			
		}
	}
	return Instance;
}


//-(void) releaseSqlite
//{
//	[Instance close];
//	[Instance release];
//}
@end
