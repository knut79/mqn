//
//  GameEndHelper.h
//  MQNorway
//
//  Created by knut dullum on 09/01/2012.
//  Copyright (c) 2012 lemmus. All rights reserved.
//
#import <UIKit/UIKit.h>

@protocol SetScoreDelegate;
@interface SetScoreBridge : NSObject<NSXMLParserDelegate>
{
    id <SetScoreDelegate> delegate;

    NSMutableData *webData;
    NSMutableString *soapResults;
    NSXMLParser *xmlParser;
	BOOL recordPosition;
	BOOL recordUserMessage;
    
    
    NSString* m_position;
    NSString* m_userMessage;

}
@property (nonatomic, assign) id <SetScoreDelegate> delegate;
-(void) setScore ;
-(NSString*) getUserMessage;
@end


@protocol SetScoreDelegate <NSObject>

@optional
-(void) gotScoreResult;
-(void) noScoreResultConnection;
@end