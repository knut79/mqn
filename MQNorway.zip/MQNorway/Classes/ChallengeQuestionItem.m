//
//  ChallengeQuestionItem.m
//  MQNorway
//
//  Created by knut dullum on 13/01/2012.
//  Copyright (c) 2012 lemmus. All rights reserved.
//

#import "ChallengeQuestionItem.h"

@implementation ChallengeQuestionItem

@synthesize qid;
@synthesize kmLeft;
@synthesize kmTimeBonus;
@synthesize answered;

@end
