//
//  County.h
//  MQNorway
//
//  Created by knut dullum on 29/04/2011.
//  Copyright 2011 lemmus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MpRegion.h"
#import "EnumDefs.h"


@interface County : MpRegion {
	
}
-(NSString*) GetBorderString;
@end