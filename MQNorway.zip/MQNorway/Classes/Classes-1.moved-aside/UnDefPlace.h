//
//  unDefPlace.h
//  MQNorway
//
//  Created by knut dullum on 11/02/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface unDefPlace : NSObject {

}

@end
