//
//  Island.h
//  MQNorway
//
//  Created by knut dullum on 27/02/2011.
//  Copyright 2011 Lemmus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MpRegion.h"
#import "EnumDefs.h"


@interface Island : MpRegion {

}

@end
